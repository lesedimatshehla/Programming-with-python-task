# LaTeX-IUBH-Template

This is a rudimentary LaTeX set-up to help students at IUBH-Online to realize assignments, workbooks, bachelor-thesis or masters' thesis. It includes a few common LaTeX formats and macros which must be adapted to the precise needs.

Tested with `pdflatex` (using the TeXlive distribution).

Delivered under the apache public license (feel free to adapt it and redistribute it in your own method, closed source or not).

Maintained by @polx based on works of Jörg Sawatzki and Ralf Kneuper.

