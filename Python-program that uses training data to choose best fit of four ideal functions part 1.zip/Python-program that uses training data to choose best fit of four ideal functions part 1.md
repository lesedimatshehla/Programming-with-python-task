**Full name:** Lesedi Kopeledi Matshehla  
    
**Description of the Task:** Python-program that uses training data to choose the four ideal
functions which are the best fit out of the fifty provided (C) *. You get (A) 4 training datasets and
(B) one test dataset, as well as (C) datasets for 50 ideal functions. All data respectively consists of
x-y-pairs of values.


```python
""" 
This is a Python-program that uses training data to choose the 
four ideal functions which are the best fit out of the fifty provided (C) *. 

    i)  Afterwards, the program uses the test data provided (B) to determine 
        for each and every x-y-pair of values whether or not they can be assigned to the 
        four chosen ideal functions**; if so, the programs to executes the mapping 
        and saves it together with the deviation at hand. 

    ii) All data is visualized logically 

    iii) Where possible, suitable unit-test were compiled 

""" 

import sys     # Standard library imports 
import pandas as pd   # related third party imports 
import numpy as np 
from matplotlib import pyplot as plt 
from sqlalchemy import create_engine 


class FindFunctions: 
    def __init__(self): 
        pass 

    def find_ideal_matches(self, train_fun, ideal_fun): 

        """ 

        function finds matches between training functions and ideal functions based on min(MSE) 
        :param train_fun: define training functions 
        :param ideal_fun: define ideal functions set 
        :return: ideal functions dataframe and their deviations 
        """ 

        # find last parameters of both fucntions 
        if isinstance(train_fun, pd.DataFrame) and isinstance(ideal_fun, pd.DataFrame): 
            ideal_lcol = len(ideal_fun.columns) 
            train_lrow = train_fun.index[-1] + 1 
            train_col = len(train_fun.columns) 

            # Loop and find perfect four functions 
            index_list = []  # here 4 ideal indexes will be strored 
            least_square = []  # here 4 ideal MSEs will be stored 

            for j in range(1, train_col):  # loop through 4 train functions 
                least_square1 = [] 
                for k in range(1, ideal_lcol):  # loop through 50 ideal functions 
                    MSE_sum = 0  # Sum MSE 

                    for i in range(train_lrow):  # calculate MSE Y value of train and Y value of ideal function 
                        z1 = train_fun.iloc[i, j]  # Train y value 
                        z2 = ideal_fun.iloc[i, k]  # Ideal y value 
                        MSE_sum = MSE_sum + ((z1 - z2) ** 2) 

                    least_square1.append(MSE_sum / train_lrow) 

                min_least = min(least_square1) 
                index = least_square1.index(min_least)  # find index of the ideal function 
                index_list.append(index + 1) 
                least_square.append(min_least) 

            per_frame = pd.DataFrame(list(zip(index_list, least_square)), columns=["Index", "least_square_value"]) 

            return per_frame 

        else: 
            raise TypeError("Given arguments are not of Dataframe type.") 

    def find_ideal_via_row(self, test_fun): 

        """ 
        determine for each and every x-y-pair of values whether they can be assigned to the four chosen ideal functions 
        :param test_fun: Dataframe with x and y values 
        :return: test function paired with values from the four ideal functions 
        """ 

        if isinstance(test_fun, pd.DataFrame): 
            test_lrow = test_fun.index[-1] + 1  # last row of the test df (used for loop) 
            test_lcol = len(test_fun.columns)  # last columns of the test df (used for loop) 
            # print(test) 

            ideal_index = []  # list to store index of ideal function 
            deviation = []  # list to store Deviation 
            for j in range(test_lrow):  # loop through rows 
                MSE_l = []  # list to store all four deviations 
                
                for i in range(2, test_lcol):  # loop through columns 2, 3, 4, 5 
                    z1 = test_fun.iloc[j, 1] 
                    z2 = test_fun.iloc[j, i] 
                    MSE_sum = ((z2 - z1) ** 2)  # calculate MSE 
                    MSE_l.append(MSE_sum)  # append MSE to the MSE_l list 

                min_least = min(MSE_l)  # select min deviation in MSE_l 

                if min_least < (np.sqrt(2)): 
                    deviation.append(min_least)  # append min_least to the deviation list 
                    index = MSE_l.index(min_least)  # select index of the min_least to find ideal function 
                    ideal_index.append(index)  # append index to the ideal_index list 

                else: 

                    deviation.append(min_least) 
                    ideal_index.append("Miss")  # no criteria match 

 
            # Add two new columns to the test 
            test["Deviation"] = deviation 
            test["Ideal index"] = ideal_index 

            return test 

        else: 
            raise TypeError("Given argument is not of Dataframe type.") 

    def prepare_graphs(self, x_fun, x_par, y1_fun, y1_par, y2_fun, y2_par, show_plots=True): 

        """ 
        function prepares a plot based on given paramaters 
        :param x_fun: x function 
        :param x_par: x position 
        :param y1_fun: y1 function 
        :param y1_par: y1 position 
        :param y2_fun: y2 function 
        :param y2_par: y2 position 
        :param show_plots: True/False to display plot 
        :return: graph of x and y 
        """ 

 

        x = x_fun.iloc[:, x_par]    # x 
        y1 = y1_fun.iloc[:, y1_par]     # y1 (training function) 
        y2 = y2_fun.iloc[:, y2_par]     # y2 (ideal function) 

        # print(y1, y2) 

        plt.plot(x, y1, c="r", label="Train function")  # plot both axis 
        plt.plot(x, y2, c="b", label="Ideal function") 
        plt.xlabel("x") 
        plt.ylabel("y") 
        plt.legend(loc=3) 

        if show_plots is True: 
            plt.show()  # show current plot 
            plt.clf()   # clear plots 
        elif show_plots is False: 
            pass 
        else: 
            pass  # no paramater show_plots or wrong paramater show_plots was given 

 
print("The first part of the program executed without errors.") 

class SqliteDb(FindFunctions): 

    """ 
    Load data into Sqlite database 
    """ 

    def db_and_table_creation(self, dataframe, db_name, table_name): 

        """ 
        function creates a database from a dataframe input 
        :param dataframe: dataframe 
        :param db_name: database name 
        :param table_name: table name 
        :return: database file into the same folder as the project 
        """ 
        try: 
            engine = create_engine(f"sqlite:///{IU_Assignment}.db", echo=True)  # insert name of the DB 
            sqlite_connection = engine.connect()  # connect to the DB 
            
            for i in range(len(dataframes)):  # loop through list of dataframes 
                dataframez = dataframe[i] 
                dataframez.to_sql(table_name[i], sqlite_connection, if_exists="fail")  # load dataframe to DB 
            sqlite_connection.close()   # close connection 
            
        except Exception: 
            exception_type, exception_value, exception_traceback = sys.exc_info()  # get exception info 
            print(exception_type, exception_value, exception_traceback)     #return exception info to the user 

print("The database created successfully.") 
 
# read CSV files and load them into Dataframes 
train = pd.read_csv("train.csv") 
ideal = pd.read_csv("ideal.csv") 
test = pd.read_csv("test.csv") 

print("Read CSV files and load them into Dataframes.") 
print("") 

# Check data formats 
print("Train dataset") 
print(train) 
print("") 

print("Ideal dataset") 
print(ideal) 
print("") 

print("Test dataset") 
print(test) 
print("") 

 

# get ideal functions based on train data 
print("Get ideal functions based on train data.") 
df = FindFunctions().find_ideal_matches(train, ideal) 
print(df)  

# plot graph of all 4 pair functions together 
print("") 
print("The selected four ideal functions 11, 41, 42, and 48 are the best fit of training data ") 
print("Plot graph of all 4 pair functions together.") 

graph = FindFunctions() 
for i in range(1, len(train.columns)): 
    graph.prepare_graphs(train, 0, train, i, ideal, df.iloc[i-1, 0], False) 

# Clean test df 
test = test.sort_values(by=["x"], ascending=True)   # sort by x 
test = test.reset_index()   # reset index 
test = test.drop(columns=["index"])     # drop old index column 

print("") 
print("Clean test df") 

# Get x, y values of each of the 4 ideal functions
print("") 
print("Get x, y values of each of the 4 ideal functions.") 
ideals = []
for i in range(0, 4):
    ideals.append(ideal[["x", f"y{str(df.iloc[i, 0])}"]])

# merge test and 4 ideal functions
print("") 
print("Merge test and 4 ideal functions.") 
for i in ideals:
    test = test.merge(i, on="x", how="left")

# determine for each and every x-y-pair of values whether or not they can be assigned to the four chosen ideal functions
print("") 
print("Determine for each and every x-y-pair of values whether or not they can be assigned to the four chosen ideal functions.") 
test = FindFunctions().find_ideal_via_row(test)  
print(test)

# Replace values with ideal function names
print("") 
print("Replace values with ideal function names.")
for i in range(0, 4):
    test["Ideal index"] = test["Ideal index"].replace([i], str(f"y{df.iloc[i, 0]}"))
    
# add y values to another test_fun (used later for scatter plot)
print("") 
print("Add y values to another test_fun (used later for scatter plot).")
test_scat = test
test_scat["ideal y value"] = ""
for i in range(0, 100):
    k = test_scat.iloc[i, 7]
    if k == "y42":
        test_scat.iloc[i, 8] = test_scat.iloc[i, 2]
    elif k == "y41":
        test_scat.iloc[i, 8] = test_scat.iloc[i, 3]
    elif k == "y11":
        test_scat.iloc[i, 8] = test_scat.iloc[i, 4]
    elif k == "y48":
        test_scat.iloc[i, 8] = test_scat.iloc[i, 5]
    elif k == "Miss":
        test_scat.iloc[i, 8] = test_scat.iloc[i, 1]
print(test_scat)

# Drop other columns that are not used
print("") 
print("Drop other columns that are not used.")
test = test.drop(columns=["y42", "y41", "y11", "y48", "ideal y value"])
print(test)

# rename columns for the train table
print("") 
print("Rename columns for the train table.")
train = train.rename(columns={"y1": "Y1 (training func)", "y2": "Y2 (training func)",
                              "y3": "Y3 (training func)", "y4": "Y4 (training func)"})
print(train)

# rename columns for the ideal table
print("") 
print("Rename columns for the ideal table.")
for col in ideal.columns:       # rename columns in ideal to fit criteria
    if len(col) > 1:    # if column name is not x, therefore > 1
        ideal = ideal.rename(columns={col: f"{col} (ideal func)"})

print(ideal)
ideal_excel = 'Rename_Ideal_Columns.xlsx'
# saving to excel
ideal.to_excel(ideal_excel)
print('DataFrame is written to Excel File successfully.')

# rename columns for the test table
print("") 
print("Rename columns for the test table.")
test = test.rename(columns={"x": "X (test func)",
                            "y": "Y (test func)",
                            "Deviation": "Delta Y (test func)",
                            "Ideal index": "No. of ideal func"})
print(test)

# Load data to sqlite
#assignment_database
print("") 
print("Load data to sqlite.")
dbs = SqliteDb()
dataframes = [train, ideal, test]
table_names = ["train_table", "ideal_table", "test_table"]
dbs.db_and_table_creation(dataframes, "assignment_database", table_names)

# Visualization
# train functions
print("") 
print("Visualization.")
print("Train functions.")
plt.clf()
x = train.iloc[:, 0]
for i in range(1, len(train.columns)):
    plt.plot(x, train.iloc[:, i], c="g", label=f"Train function y{i}")
    plt.title(f"Train function y{i}.")
    plt.legend(bbox_to_anchor=(1.05, 1.0), loc='upper left')
    plt.xlabel("x")
    plt.ylabel(f"y{i}")
    plt.show()
    plt.clf()
    
# ideal functions (4 chosen)
print("") 
print("Ideal functions (4 chosen).")
plt.clf()
x = train.iloc[:, 0]
for i in range(0, df.index[-1] + 1):
    y = df.iloc[i, 0]  # get ideal y column number (42, 41, 11, 48)
    plt.plot(x, ideal.iloc[:, y], c="#FF4500", label=f"Ideal function y{y}")
    plt.title(f"The Chosen Ideal Function y{y}.")
    plt.legend(bbox_to_anchor=(1.05, 1.0), loc='upper left')
    plt.xlabel("x")
    plt.ylabel(f"y{y}")
    plt.show()
    plt.clf()

        
# test scatter (show points of test.csv)
print("") 
print("Test scatter (show points of test.csv).")
plt.clf()  # clear previous plots
plt.scatter(test.iloc[:, 0], test.iloc[:, 1])  # select x and y values
plt.title("Test scatter (show points of test.csv).")
plt.xlabel("x")
plt.ylabel("y")
plt.show()

plt.clf()  # clear previous plots
# create lists to visualize test_scat dataframe
print("") 
print("Create lists to visualize test_scat dataframe.")
x1 = []
x2 = []
x3 = []
x4 = []
xm = []
y1 = []
y2 = []
y3 = []
y4 = []
ym = []

# append x and y values to the upper lists
print("") 
print("Append x and y values to the upper lists.")
for i in range(0, 100):
    k = test_scat.iloc[i, 7]
    if k == "y42":
        x1.append(test_scat.iloc[i, 0])  # append x value of y42 to the x1 list
        y1.append(test_scat.iloc[i, 8])  # append y value of y42 to the y1 list
    elif k == "y41":
        x2.append(test_scat.iloc[i, 0])  # append x value of y41 to the x2 list
        y2.append(test_scat.iloc[i, 8])  # append y value of y41 to the y2 list
    elif k == "y11":
        x3.append(test_scat.iloc[i, 0])  # append x value of y11 to the x3 list
        y3.append(test_scat.iloc[i, 8])  # append y value of y11 to the y3 list
    elif k == "y48":
        x4.append(test_scat.iloc[i, 0])  # append x value of y48 to the x4 list
        y4.append(test_scat.iloc[i, 8])  # append y value of y48 to the y4 list
    elif k == "Miss":
        xm.append(test_scat.iloc[i, 0])  # append x value of "Miss" values to the xm list
        ym.append(test_scat.iloc[i, 8])  # append y value of "Miss" values to the ym list
        
# plot ideal functions and test y-values on the same scatter plot
print("") 
print("Plot ideal functions and test y-values on the same scatter plot.")
plt.scatter(x1, y1, marker="o", label="Test - y42", color="r")
plt.scatter(x2, y2, marker="s", label="Test - y41", color="b")
plt.scatter(x3, y3, marker="^", label="Test - y11", color="g")
plt.scatter(x4, y4, marker="d", label="Test - y48", color="#FFD700")
plt.scatter(xm, ym, marker="x", label="Test - Miss", color="#000000")
plt.plot(ideal.iloc[:, 0], ideal.iloc[:, 42], label="Ideal - Y42", color="#FA8072")
plt.plot(ideal.iloc[:, 0], ideal.iloc[:, 41], label="Ideal - Y41", color="#1E90FF")
plt.plot(ideal.iloc[:, 0], ideal.iloc[:, 11], label="Ideal - Y11", color="#7CFC00")
plt.plot(ideal.iloc[:, 0], ideal.iloc[:, 48], label="Ideal - Y48", color="#FFA500")
plt.title("Scatter plot of ideal functions and test y-values.")
plt.xlabel("x")
plt.ylabel("y")
plt.legend(bbox_to_anchor=(1.05, 1.0), loc='upper left')
plt.show()

# ideal functions (all 50)
print("") 
print("Ideal functions (all 50).")
plt.clf()
x = ideal.iloc[:, 0]
for i in range(1, len(ideal.columns)):
    plt.plot(x, ideal.iloc[:, i], c="#FF4500", label=f"Ideal function y{i}")
    plt.title(f"Ideal Function y{i}.")
    plt.legend(bbox_to_anchor=(1.05, 1.0), loc='upper left')
    plt.xlabel("x")
    plt.ylabel(f"y{i}")
    plt.show()
    plt.clf()
```

    The first part of the program executed without errors.
    The database created successfully.
    Read CSV files and load them into Dataframes.
    
    Train dataset
            x         y1         y2         y3        y4
    0   -20.0  39.778572 -40.078590 -20.214268 -0.324914
    1   -19.9  39.604813 -39.784000 -20.070950 -0.058820
    2   -19.8  40.099070 -40.018845 -19.906782 -0.451830
    3   -19.7  40.151100 -39.518402 -19.389118 -0.612044
    4   -19.6  39.795662 -39.360065 -19.815890 -0.306076
    ..    ...        ...        ...        ...       ...
    395  19.5 -38.254158  39.661987  19.536741  0.695158
    396  19.6 -39.106945  39.067880  19.840752  0.638423
    397  19.7 -38.926495  40.211475  19.516634  0.109105
    398  19.8 -39.276672  40.038870  19.377943  0.189025
    399  19.9 -39.724934  40.558865  19.630678  0.513824
    
    [400 rows x 5 columns]
    
    Ideal dataset
            x        y1        y2         y3        y4         y5        y6  \
    0   -20.0 -0.912945  0.408082   9.087055  5.408082  -9.087055  0.912945   
    1   -19.9 -0.867644  0.497186   9.132356  5.497186  -9.132356  0.867644   
    2   -19.8 -0.813674  0.581322   9.186326  5.581322  -9.186326  0.813674   
    3   -19.7 -0.751573  0.659649   9.248426  5.659649  -9.248426  0.751573   
    4   -19.6 -0.681964  0.731386   9.318036  5.731386  -9.318036  0.681964   
    ..    ...       ...       ...        ...       ...        ...       ...   
    395  19.5  0.605540  0.795815  10.605540  5.795815 -10.605540 -0.605540   
    396  19.6  0.681964  0.731386  10.681964  5.731386 -10.681964 -0.681964   
    397  19.7  0.751573  0.659649  10.751574  5.659649 -10.751574 -0.751573   
    398  19.8  0.813674  0.581322  10.813674  5.581322 -10.813674 -0.813674   
    399  19.9  0.867644  0.497186  10.867644  5.497186 -10.867644 -0.867644   
    
               y7        y8        y9  ...        y41        y42       y43  \
    0   -0.839071 -0.850919  0.816164  ... -40.456474  40.204040  2.995732   
    1   -0.865213  0.168518  0.994372  ... -40.233820  40.048590  2.990720   
    2   -0.889191  0.612391  1.162644  ... -40.006836  39.890660  2.985682   
    3   -0.910947 -0.994669  1.319299  ... -39.775787  39.729824  2.980619   
    4   -0.930426  0.774356  1.462772  ... -39.540980  39.565693  2.975530   
    ..        ...       ...       ...  ...        ...        ...       ...   
    395 -0.947580 -0.117020  1.591630  ...  39.302770 -38.602093  2.970414   
    396 -0.930426  0.774356  1.462772  ...  39.540980 -38.834310  2.975530   
    397 -0.910947 -0.994669  1.319299  ...  39.775787 -39.070175  2.980619   
    398 -0.889191  0.612391  1.162644  ...  40.006836 -39.309338  2.985682   
    399 -0.865213  0.168518  0.994372  ...  40.233820 -39.551407  2.990720   
    
              y44        y45       y46       y47       y48       y49       y50  
    0   -0.008333  12.995732  5.298317 -5.298317 -0.186278  0.912945  0.396850  
    1   -0.008340  12.990720  5.293305 -5.293305 -0.215690  0.867644  0.476954  
    2   -0.008347  12.985682  5.288267 -5.288267 -0.236503  0.813674  0.549129  
    3   -0.008354  12.980619  5.283204 -5.283204 -0.247887  0.751573  0.612840  
    4   -0.008361  12.975530  5.278115 -5.278115 -0.249389  0.681964  0.667902  
    ..        ...        ...       ...       ...       ...       ...       ...  
    395 -0.012422  12.970414  5.273000 -5.273000  0.240949  0.605540  0.714434  
    396 -0.012438  12.975530  5.278115 -5.278115  0.249389  0.681964  0.667902  
    397 -0.012453  12.980619  5.283204 -5.283204  0.247887  0.751573  0.612840  
    398 -0.012469  12.985682  5.288267 -5.288267  0.236503  0.813674  0.549129  
    399 -0.012484  12.990720  5.293305 -5.293305  0.215690  0.867644  0.476954  
    
    [400 rows x 51 columns]
    
    Test dataset
           x          y
    0   17.5  34.161040
    1    0.3   1.215102
    2   -8.7 -16.843908
    3  -19.2 -37.170870
    4  -11.0 -20.263054
    ..   ...        ...
    95  -1.9  -4.036904
    96  12.2  -0.010358
    97  16.5 -33.964134
    98   5.3 -10.291622
    99  17.9  28.078455
    
    [100 rows x 2 columns]
    
    Get ideal functions based on train data.
       Index  least_square_value
    0     42            0.085616
    1     41            0.089005
    2     11            0.074655
    3     48            0.079909
    
    The selected four ideal functions 11, 41, 42, and 48 are the best fit of training data 
    Plot graph of all 4 pair functions together.
    
    Clean test df
    
    Get x, y values of each of the 4 ideal functions.
    
    Merge test and 4 ideal functions.
    
    Determine for each and every x-y-pair of values whether or not they can be assigned to the four chosen ideal functions.
           x          y        y42        y41   y11       y48  Deviation  \
    0  -20.0 -19.284970  40.204040 -40.456474 -20.0 -0.186278   0.511268   
    1  -19.8 -19.915014  39.890660 -40.006836 -19.8 -0.236503   0.013228   
    2  -19.3 -38.458572  39.050125 -38.817684 -19.3 -0.195970   0.128961   
    3  -19.2 -37.170870  38.869610 -38.571660 -19.2 -0.161224   1.962213   
    4  -19.1 -38.155376  38.684402 -38.323917 -19.1 -0.120051   0.028406   
    ..   ...        ...        ...        ...   ...       ...        ...   
    95  18.2  18.535152 -36.001823  36.097584  18.2 -0.240830   0.112327   
    96  18.7   0.832272 -36.905582  37.325500  18.7 -0.073668   0.820727   
    97  18.8  37.523400 -37.100613  37.575233  18.8 -0.024737   0.002687   
    98  18.9  19.193245 -37.300636  37.825210  18.9  0.025179   0.085993   
    99  19.7  38.955273 -39.070175  39.775787  19.7  0.247887   0.673243   
    
       Ideal index  
    0            2  
    1            2  
    2            1  
    3         Miss  
    4            1  
    ..         ...  
    95           2  
    96           3  
    97           1  
    98           2  
    99           1  
    
    [100 rows x 8 columns]
    
    Replace values with ideal function names.
    
    Add y values to another test_fun (used later for scatter plot).
           x          y        y42        y41   y11       y48  Deviation  \
    0  -20.0 -19.284970  40.204040 -40.456474 -20.0 -0.186278   0.511268   
    1  -19.8 -19.915014  39.890660 -40.006836 -19.8 -0.236503   0.013228   
    2  -19.3 -38.458572  39.050125 -38.817684 -19.3 -0.195970   0.128961   
    3  -19.2 -37.170870  38.869610 -38.571660 -19.2 -0.161224   1.962213   
    4  -19.1 -38.155376  38.684402 -38.323917 -19.1 -0.120051   0.028406   
    ..   ...        ...        ...        ...   ...       ...        ...   
    95  18.2  18.535152 -36.001823  36.097584  18.2 -0.240830   0.112327   
    96  18.7   0.832272 -36.905582  37.325500  18.7 -0.073668   0.820727   
    97  18.8  37.523400 -37.100613  37.575233  18.8 -0.024737   0.002687   
    98  18.9  19.193245 -37.300636  37.825210  18.9  0.025179   0.085993   
    99  19.7  38.955273 -39.070175  39.775787  19.7  0.247887   0.673243   
    
       Ideal index ideal y value  
    0          y11         -20.0  
    1          y11         -19.8  
    2          y41    -38.817684  
    3         Miss     -37.17087  
    4          y41    -38.323917  
    ..         ...           ...  
    95         y11          18.2  
    96         y48     -0.073668  
    97         y41     37.575233  
    98         y11          18.9  
    99         y41     39.775787  
    
    [100 rows x 9 columns]
    
    Drop other columns that are not used.
           x          y  Deviation Ideal index
    0  -20.0 -19.284970   0.511268         y11
    1  -19.8 -19.915014   0.013228         y11
    2  -19.3 -38.458572   0.128961         y41
    3  -19.2 -37.170870   1.962213        Miss
    4  -19.1 -38.155376   0.028406         y41
    ..   ...        ...        ...         ...
    95  18.2  18.535152   0.112327         y11
    96  18.7   0.832272   0.820727         y48
    97  18.8  37.523400   0.002687         y41
    98  18.9  19.193245   0.085993         y11
    99  19.7  38.955273   0.673243         y41
    
    [100 rows x 4 columns]
    
    Rename columns for the train table.
            x  Y1 (training func)  Y2 (training func)  Y3 (training func)  \
    0   -20.0           39.778572          -40.078590          -20.214268   
    1   -19.9           39.604813          -39.784000          -20.070950   
    2   -19.8           40.099070          -40.018845          -19.906782   
    3   -19.7           40.151100          -39.518402          -19.389118   
    4   -19.6           39.795662          -39.360065          -19.815890   
    ..    ...                 ...                 ...                 ...   
    395  19.5          -38.254158           39.661987           19.536741   
    396  19.6          -39.106945           39.067880           19.840752   
    397  19.7          -38.926495           40.211475           19.516634   
    398  19.8          -39.276672           40.038870           19.377943   
    399  19.9          -39.724934           40.558865           19.630678   
    
         Y4 (training func)  
    0             -0.324914  
    1             -0.058820  
    2             -0.451830  
    3             -0.612044  
    4             -0.306076  
    ..                  ...  
    395            0.695158  
    396            0.638423  
    397            0.109105  
    398            0.189025  
    399            0.513824  
    
    [400 rows x 5 columns]
    
    Rename columns for the ideal table.
            x  y1 (ideal func)  y2 (ideal func)  y3 (ideal func)  y4 (ideal func)  \
    0   -20.0        -0.912945         0.408082         9.087055         5.408082   
    1   -19.9        -0.867644         0.497186         9.132356         5.497186   
    2   -19.8        -0.813674         0.581322         9.186326         5.581322   
    3   -19.7        -0.751573         0.659649         9.248426         5.659649   
    4   -19.6        -0.681964         0.731386         9.318036         5.731386   
    ..    ...              ...              ...              ...              ...   
    395  19.5         0.605540         0.795815        10.605540         5.795815   
    396  19.6         0.681964         0.731386        10.681964         5.731386   
    397  19.7         0.751573         0.659649        10.751574         5.659649   
    398  19.8         0.813674         0.581322        10.813674         5.581322   
    399  19.9         0.867644         0.497186        10.867644         5.497186   
    
         y5 (ideal func)  y6 (ideal func)  y7 (ideal func)  y8 (ideal func)  \
    0          -9.087055         0.912945        -0.839071        -0.850919   
    1          -9.132356         0.867644        -0.865213         0.168518   
    2          -9.186326         0.813674        -0.889191         0.612391   
    3          -9.248426         0.751573        -0.910947        -0.994669   
    4          -9.318036         0.681964        -0.930426         0.774356   
    ..               ...              ...              ...              ...   
    395       -10.605540        -0.605540        -0.947580        -0.117020   
    396       -10.681964        -0.681964        -0.930426         0.774356   
    397       -10.751574        -0.751573        -0.910947        -0.994669   
    398       -10.813674        -0.813674        -0.889191         0.612391   
    399       -10.867644        -0.867644        -0.865213         0.168518   
    
         y9 (ideal func)  ...  y41 (ideal func)  y42 (ideal func)  \
    0           0.816164  ...        -40.456474         40.204040   
    1           0.994372  ...        -40.233820         40.048590   
    2           1.162644  ...        -40.006836         39.890660   
    3           1.319299  ...        -39.775787         39.729824   
    4           1.462772  ...        -39.540980         39.565693   
    ..               ...  ...               ...               ...   
    395         1.591630  ...         39.302770        -38.602093   
    396         1.462772  ...         39.540980        -38.834310   
    397         1.319299  ...         39.775787        -39.070175   
    398         1.162644  ...         40.006836        -39.309338   
    399         0.994372  ...         40.233820        -39.551407   
    
         y43 (ideal func)  y44 (ideal func)  y45 (ideal func)  y46 (ideal func)  \
    0            2.995732         -0.008333         12.995732          5.298317   
    1            2.990720         -0.008340         12.990720          5.293305   
    2            2.985682         -0.008347         12.985682          5.288267   
    3            2.980619         -0.008354         12.980619          5.283204   
    4            2.975530         -0.008361         12.975530          5.278115   
    ..                ...               ...               ...               ...   
    395          2.970414         -0.012422         12.970414          5.273000   
    396          2.975530         -0.012438         12.975530          5.278115   
    397          2.980619         -0.012453         12.980619          5.283204   
    398          2.985682         -0.012469         12.985682          5.288267   
    399          2.990720         -0.012484         12.990720          5.293305   
    
         y47 (ideal func)  y48 (ideal func)  y49 (ideal func)  y50 (ideal func)  
    0           -5.298317         -0.186278          0.912945          0.396850  
    1           -5.293305         -0.215690          0.867644          0.476954  
    2           -5.288267         -0.236503          0.813674          0.549129  
    3           -5.283204         -0.247887          0.751573          0.612840  
    4           -5.278115         -0.249389          0.681964          0.667902  
    ..                ...               ...               ...               ...  
    395         -5.273000          0.240949          0.605540          0.714434  
    396         -5.278115          0.249389          0.681964          0.667902  
    397         -5.283204          0.247887          0.751573          0.612840  
    398         -5.288267          0.236503          0.813674          0.549129  
    399         -5.293305          0.215690          0.867644          0.476954  
    
    [400 rows x 51 columns]
    DataFrame is written to Excel File successfully.
    
    Rename columns for the test table.
        X (test func)  Y (test func)  Delta Y (test func) No. of ideal func
    0           -20.0     -19.284970             0.511268               y11
    1           -19.8     -19.915014             0.013228               y11
    2           -19.3     -38.458572             0.128961               y41
    3           -19.2     -37.170870             1.962213              Miss
    4           -19.1     -38.155376             0.028406               y41
    ..            ...            ...                  ...               ...
    95           18.2      18.535152             0.112327               y11
    96           18.7       0.832272             0.820727               y48
    97           18.8      37.523400             0.002687               y41
    98           18.9      19.193245             0.085993               y11
    99           19.7      38.955273             0.673243               y41
    
    [100 rows x 4 columns]
    
    Load data to sqlite.
    <class 'NameError'> name 'IU_Assignment' is not defined <traceback object at 0x000001203BF7E0C0>
    
    Visualization.
    Train functions.
    


    
![png](output_1_1.png)
    



    
![png](output_1_2.png)
    



    
![png](output_1_3.png)
    



    
![png](output_1_4.png)
    


    
    Ideal functions (4 chosen).
    


    
![png](output_1_6.png)
    



    
![png](output_1_7.png)
    



    
![png](output_1_8.png)
    



    
![png](output_1_9.png)
    


    
    Test scatter (show points of test.csv).
    


    
![png](output_1_11.png)
    


    
    Create lists to visualize test_scat dataframe.
    
    Append x and y values to the upper lists.
    
    Plot ideal functions and test y-values on the same scatter plot.
    


    
![png](output_1_13.png)
    


    
    Ideal functions (all 50).
    


    
![png](output_1_15.png)
    



    
![png](output_1_16.png)
    



    
![png](output_1_17.png)
    



    
![png](output_1_18.png)
    



    
![png](output_1_19.png)
    



    
![png](output_1_20.png)
    



    
![png](output_1_21.png)
    



    
![png](output_1_22.png)
    



    
![png](output_1_23.png)
    



    
![png](output_1_24.png)
    



    
![png](output_1_25.png)
    



    
![png](output_1_26.png)
    



    
![png](output_1_27.png)
    



    
![png](output_1_28.png)
    



    
![png](output_1_29.png)
    



    
![png](output_1_30.png)
    



    
![png](output_1_31.png)
    



    
![png](output_1_32.png)
    



    
![png](output_1_33.png)
    



    
![png](output_1_34.png)
    



    
![png](output_1_35.png)
    



    
![png](output_1_36.png)
    



    
![png](output_1_37.png)
    



    
![png](output_1_38.png)
    



    
![png](output_1_39.png)
    



    
![png](output_1_40.png)
    



    
![png](output_1_41.png)
    



    
![png](output_1_42.png)
    



    
![png](output_1_43.png)
    



    
![png](output_1_44.png)
    



    
![png](output_1_45.png)
    



    
![png](output_1_46.png)
    



    
![png](output_1_47.png)
    



    
![png](output_1_48.png)
    



    
![png](output_1_49.png)
    



    
![png](output_1_50.png)
    



    
![png](output_1_51.png)
    



    
![png](output_1_52.png)
    



    
![png](output_1_53.png)
    



    
![png](output_1_54.png)
    



    
![png](output_1_55.png)
    



    
![png](output_1_56.png)
    



    
![png](output_1_57.png)
    



    
![png](output_1_58.png)
    



    
![png](output_1_59.png)
    



    
![png](output_1_60.png)
    



    
![png](output_1_61.png)
    



    
![png](output_1_62.png)
    



    
![png](output_1_63.png)
    



    
![png](output_1_64.png)
    



    <Figure size 640x480 with 0 Axes>



```python

```
